<?php
/**
 * Template Name: Archives Page
 *
 * A custom page template that display site archives.
 *
 * The "Template Name:" bit above allows this to be selectable
 * from a dropdown menu on the edit page screen.
 *
 * @package WordPress
 * @subpackage monochrome
 */

get_header(); ?>

		<div id="container">
			<div id="content" role="main">

<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>

				<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<?php if ( is_front_page() ) { ?>
						<h2 class="entry-title"><?php the_title(); ?></h2>
					<?php } else { ?>	
						<h1 class="entry-title"><?php the_title(); ?></h1>
					<?php } ?>				

					<div class="entry-content">
						<?php the_content(); ?>
                        
                        <h4>Archives by post</h4>
                        <ul>
                        <?php
                        	/* inserting a maximum of 100 posts */
							$posts = get_posts('numberposts=100&offset=0');
							foreach($posts as $post){
								setup_postdata($post);
								echo '<li><a href="'.get_permalink($post->ID).'" title="'.get_the_title($post->ID).'">'.get_the_title($post->ID).'</a></li>';
							}
						?>
                        </ul><?php wp_reset_query(); ?>
                        <h4>Archives by category</h4>
                        <ul><?php wp_list_categories('title_li=&show_count=1&feed=RSS'); ?></ul>

                        <h4>Archives by month</h4>
                        <ul><?php wp_get_archives('type=monthly&show_post_count=1') ?></ul>
                        
						<?php edit_post_link( __( 'Edit', 'monochrome' ), '<span class="edit-link">', '</span>' ); ?>
					</div><!-- .entry-content -->
				</div><!-- #post-## -->

				<?php // comments_template( '', true ); ?>

<?php endwhile; ?>

			</div><!-- #content -->
		</div><!-- #container -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
