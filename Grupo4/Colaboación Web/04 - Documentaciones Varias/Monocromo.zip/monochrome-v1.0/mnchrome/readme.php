<label>1. Requirements:</label>
<p>- WordPress 3.0+</p>
<p>- Host server with PHP5+</p>
<br /><br />

<label>2. Installation</label>
<p>- Install Monochrome folder by uploading it at /wp-content/themes/</p>
<p>- Go to APPEARANCE > THEMES then activate Monochrome by Wpcrunchy</p>
<br /><br />

<label>3. Optional: Supported Plugins (Integrates Automatically):</label>
<p>- WP-Pagenavi (http://wordpress.org/extend/plugins/wp-pagenavi/)</p>
<br /><br />

<label>4. Customizing Cobalt Magazine:</label>
<p>- Go to APPEARANCE > Cobalt Magazine Theme Options</p>
<ol>
	<li>General Settings</li>
    <li>SEO Options</li>
    <li>Layout Settings</li>
    <li>Advertisement</li>
    <li>Integration</li>
</ol>
<p>- Then click Save Settings.</p>
<br /><br />

<label>5. Adding Thumbnail in post and Image in Featured Area:</label>
<p>- While in posting area, click the SET FEATURED IMAGE button at right part of posting area.</p>
<p>- Upload an image or select an image from the gallery if you have one already.</p>
<p>- click USE AS FEATURED IMAGE after uploading is complete.</p>
<br /><br />

<label>6. Adding descriptions to the pages on the homepage:</label>
<p>Descriptions appear below the title on pages on the homepage. To add this description simply create a custom field for each post/page with the name of "Tagline" and a value of the text you would like to use for the description.</p>
<p>If your using a custom menu to manage your navigation, simply go to Appearance > Menus then look at the top right and you will notice a "Screen Option" tab. Click it and you will get the option to display several other input fields for each menu item, among them a checkbox to show the description. Once that is done,  if you start editing your items you will notice that you can now enter a description for each menu item.</p>
<br /><br />

<label>7. SUPPORT:</label>
<p>if you still confused or having difficulties installing Monochrome, feel free to post your question at our support forum (<a href="http://wpcrunchy.com/support/" target="_blank">http://wpcrunchy.com/support/</a>).</p>