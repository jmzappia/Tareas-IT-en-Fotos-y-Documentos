<div id="teaser">
    <div id="slider">
       	<ul class="accordion">
        <?php
			query_posts('showposts=5&cat=' . get_option('monochrome_featured_category'));
			if ( have_posts() ) : while ( have_posts() ) : the_post();
				if(has_post_thumbnail( $post->ID )) :
				$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' ); ?>
           	<li>
               	<span class="shadow"><!-- shadow --></span>
				<span class="caption"><?php the_title(); ?></span>
				<a href="<?php the_permalink(); ?>"><img src="<?php bloginfo('template_directory'); ?>/library/functions/timthumb.php?src=<?php echo $image[0]; ?>&amp;w=500&amp;h=290&amp;zc=1" align="tae" /></a>
			</li>
            <?php endif;
				endwhile; endif;
				wp_reset_query();
			?>
		</ul>
	</div>
</div><!-- #teaser -->