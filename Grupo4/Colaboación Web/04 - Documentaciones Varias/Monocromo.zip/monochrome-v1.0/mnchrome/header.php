<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package WordPress
 * @subpackage monochrome
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<title><?php
	/*
	 * Print the <title> tag based on what is being viewed.
	 * We filter the output of wp_title() a bit -- see
	 * monochrome_filter_wp_title() in functions.php.
	 */
	wp_title( '|', true, 'right' );

	?></title>
<?php
	/* Adding meta tags for better SEO
	 * monochrome_create_metadata() in functions.php.
	 */
	monochrome_create_metadata();
?>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<!--[if IE]>
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_directory' ); ?>/style-ie.css" />
<![endif]-->
<?php
	/* Adding custom css file for customization if enabled
	 * in theme option.
	 */
	if(get_option("monochrome_customcss") <> "") {
		echo '<link rel="stylesheet" type="text/css" media="all" href="'.get_bloginfo("template_directory").'/custom/custom.css" />';
	}
?>
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<?php
	/* We add some JavaScript to pages with the comment form
	 * to support sites with threaded comments (when in use).
	 */
	if ( is_singular() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );
		
	/*
	 * Adding robots and canonical url filter for better SEO
	 * monochrome_create_robots() and monochrome_canonical_url() in functions.php.
	 */
	 monochrome_create_robots();
	 monochrome_canonical_url();

	/* Always have wp_head() just before the closing </head>
	 * tag of your theme, or you will break many plugins, which
	 * generally use this hook to add elements to <head> such
	 * as styles, scripts, and meta tags.
	 */
	wp_head();
?>
</head>
<body <?php body_class(); ?>>
<div id="wrapper" class="hfeed">
	<div id="header">
    	<div id="masthead">
        	<div id="branding" role="banner">
            	<div id="site-logo">
                	<a href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
                    <?php if(get_option('monochrome_customlogo') <> '') : ?>
	                    <img src="<?php echo get_option('monochrome_customlogo'); ?>" align="logo" />
                    <?php else: ?>
                    	<img src="<?php bloginfo('template_directory'); ?>/library/images/logo.png" align="logo" />
                    <?php endif; ?>
					</a>
                </div>
                <div id="site-description"><?php bloginfo( 'description' ); ?></div>
                <?php if(get_option('monochrome_enable_banneradcode') == 'enable') : ?>
	                <div id="site-ad"><?php echo get_option('monochrome_banneradcode'); ?></div>
                <?php endif; ?>
            </div><!-- #branding -->
            <div id="access" role="navigation">
            	<?php wp_nav_menu( array( 'container_class' => 'menu', 'menu_class' => 'sf-menu', 'theme_location' => 'primary', 'fallback_cb' => 'monochrome_fallback_menu', 'walker' => new monochrome_description_walker() ) ); ?>
            </div><!-- #access -->
        </div><!-- #masthead -->
    </div><!-- #header -->
    
    <?php
		if(is_home() || is_front_page()) {
			if(get_option('monochrome_display_postsgallery') == 'on') {include('featured.php');}
		} else {
			include('breadcrumb.php');
		}
	?>
    
    <div id="main">