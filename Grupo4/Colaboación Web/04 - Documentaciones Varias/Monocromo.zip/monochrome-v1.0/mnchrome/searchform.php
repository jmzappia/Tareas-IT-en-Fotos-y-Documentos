<form id="searchform" method="get" action="<?php bloginfo('url'); ?>"> 
	<input type="text" name="s" id="s" class="search_term" value="Type in keyword and hit Enter..." onblur="if (this.value == '') {this.value = 'Type in keyword and hit Enter...';}"  onfocus="if (this.value == 'Type in keyword and hit Enter...') {this.value = '';}" />
</form>