<?php
/**
 * The Function containing the custom widgets for sidebar widget areas.
 *
 * @package WordPress
 * @subpackage monochrome
 *
 * 1. Popular Post
 */

class monochrome_widget_popularPosts extends WP_Widget {
	function monochrome_widget_popularPosts() {
		parent::WP_Widget(false, $name = 'monochrome Popular Posts');
	}
	function widget($args, $instance) {
        $args['title'] = $instance['title'];
		$args['post_count'] = $instance['post_count'];
		$args['display_comments'] = $instance['display_comments'];
		monochrome_popularPosts($args);
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['post_count'] = strip_tags($new_instance['post_count']);
		$instance['display_comments'] = strip_tags($new_instance['display_comments']);
        return $instance;
	}
	function form($instance) {
		$title = esc_attr($instance['title']);
		$post_count = esc_attr($instance['post_count']);
		$display_comments = esc_attr($instance['display_comments']); ?>  
        <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?> <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('post_count'); ?>"><?php _e('Post Count:'); ?> <input class="widefat" id="<?php echo $this->get_field_id('post_count'); ?>" name="<?php echo $this->get_field_name('post_count'); ?>" type="text" value="<?php echo $post_count; ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('display_comments'); ?>"><?php _e('Display Comments:'); ?> 
        <select class="widefat" id="<?php echo $this->get_field_id('display_comments'); ?>" name="<?php echo $this->get_field_name('display_comments'); ?>">
        	<option value="Yes" <?php if($display_comments == 'Yes'){echo 'selected';}?>>Yes</option>
            <option value="No" <?php if($display_comments == 'No'){echo 'selected';}?>>No</option>
		</select></label></p>
<?php
	}
}
function monochrome_popularPosts($args = array(), $interval = '') {
	global $wpdb;
	
	$postCount = $args['post_count'] <> "" ? $args['post_count'] : 5;
	$request = 'SELECT *
		FROM ' . $wpdb->posts . '
		WHERE ';
	if ($interval != '') {
		$request .= 'post_date>DATE_SUB(NOW(), ' . $interval . ') ';
	}
	$request .= 'post_status="publish"
			AND comment_count > 0
		ORDER BY comment_count DESC LIMIT 0, ' . $postCount;
	$posts = $wpdb->get_results($request);
	if (count($posts) >= 1) {
		if (!isset($args['title']) || $args['title'] == '') {
			$args['title'] = 'Popular Posts';
		}
		foreach ($posts as $post) {
			wp_cache_add($post->ID, $post, 'posts');
			$popularPosts[] = array(
				'title' => stripslashes($post->post_title),
				'url' => get_permalink($post->ID),
				'comment_count' => $post->comment_count,
			);
		}
		echo $args['before_widget'] . $args['before_title'] . $args['title'] . $args['after_title']; ?>
		<ul>
<?php foreach ($popularPosts as $post) { ?>
			<li>
				<a href="<?php echo $post['url'];?>"><?php echo $post['title']; ?></a>
<?php if ($args['display_comments'] == 'Yes') { ?>
	(<?php echo $post['comment_count'] . ' ' . __('comments', 'monochrome'); ?>)
<?php } ?>
			</li>
<?php } ?>
		</ul>
<?php echo $args['after_widget']; }
}
register_widget("monochrome_widget_popularPosts");

/**
 * 2. Subscription
 */
class monochrome_widget_subscription extends WP_Widget {
	function monochrome_widget_subscription() {
		parent::WP_Widget(false, $name = 'monochrome Subscription');
	}
	function widget($args, $instance) {
        $args['title'] = $instance['title'];
		$args['rss'] = $instance['rss'];
		$args['email'] = $instance['email'];
		$args['twitter'] = $instance['twitter'];
		monochrome_subscription($args);
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['rss'] = strip_tags($new_instance['rss']);
		$instance['email'] = strip_tags($new_instance['email']);
		$instance['twitter'] = strip_tags($new_instance['twitter']);
        return $instance;
	}
	function form($instance) {
		$title = esc_attr($instance['title']);
		$rss = esc_attr($instance['rss']);
		$email = esc_attr($instance['email']);
		$twitter = esc_attr($instance['twitter']); ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?> <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('rss'); ?>"><?php _e('Feed URL:'); ?> <input class="widefat" id="<?php echo $this->get_field_id('rss'); ?>" name="<?php echo $this->get_field_name('rss'); ?>" type="text" value="<?php echo $rss; ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('email'); ?>"><?php _e('Email Subscription URL:'); ?> <input class="widefat" id="<?php echo $this->get_field_id('email'); ?>" name="<?php echo $this->get_field_name('email'); ?>" type="text" value="<?php echo $email; ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('twitter'); ?>"><?php _e('Full Twitter URL:'); ?> <input class="widefat" id="<?php echo $this->get_field_id('twitter'); ?>" name="<?php echo $this->get_field_name('twitter'); ?>" type="text" value="<?php echo $twitter; ?>" /></label></p>
<?php
	}
}
function monochrome_subscription($args = array()) {
	if(!isset($args['title']) || $args['title'] == '') {
		$args['title'] = 'Subscription';
	}
	echo $args['before_widget'] . $args['before_title'] . $args['title'] . $args['after_title']; ?>
    <ul id="monochrome_subscription">
		<li class="rss"><a href="<?php echo $args['rss'] <> '' ? $args['rss'] : get_bloginfo('rss2_url'); ?>">Subscribe via RSS</a></li>
        <?php if($args['email'] <> '') : ?>
		<li class="email"><a href="<?php echo $args['email']; ?>">Subscribe via Email</a></li>
         <?php endif; if($args['twitter'] <> '') : ?>
		<li class="twitter"><a href="<?php echo $args['twitter']; ?>">Follow us on Twitter</a></li>
        <?php endif; ?>
    </ul>
    <?php
	echo $args['after_widget'];
}
register_widget("monochrome_widget_subscription");

/**
 * 3. Revamp Search
 */
class monochrome_widget_search extends WP_Widget {
	function monochrome_widget_search() {
		parent::WP_Widget(false, $name = 'Search');
	}
	function widget($args, $instance) {
        $args['title'] = $instance['title'];
		monochrome_search($args);
	}
	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
        return $instance;
	}
	function form($instance) {
		$title = esc_attr($instance['title']); ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?> <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
<?php
	}
}
function monochrome_search($args = array()) {
	if(!isset($args['title']) || $args['title'] == '') {
		$args['title'] = 'Search';
	}
	echo $args['before_widget'] . $args['before_title'] . $args['title'] . $args['after_title']; ?>
    	<form id="searchform" method="get" action="<?php bloginfo('url'); ?>"> 
			<input type="text" name="s" id="s" class="search_term" value="Type in keyword and hit Enter..." onblur="if (this.value == '') {this.value = 'Type in keyword and hit Enter...';}"  onfocus="if (this.value == 'Type in keyword and hit Enter...') {this.value = '';}" />
		</form>
    <?php
	echo $args['after_widget'];
}
register_widget("monochrome_widget_search");
?>