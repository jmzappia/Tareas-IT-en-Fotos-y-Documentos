NOTE: This demo font is for PERSONAL USE ONLY! But any donation is very appreciated. 

Please contact me before any commercial use.
My fonts for free use allowed only in personal projects, non-profit and charity use.
If you make money from using my fonts, Please purchase a commercial license

Link to purchase FULL VERSION and COMMERCIAL LICENSE: 
https://gumroad.com/naharstd

Paypal account for donation : 
https://paypal.me/nahar17

For information please email:
Naharstd@gmail.com

Thank you :)

Best
Naharstd