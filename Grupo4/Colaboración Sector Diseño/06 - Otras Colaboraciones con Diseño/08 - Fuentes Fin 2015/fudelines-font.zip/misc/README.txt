Hello,

If there is a problem, question, or anything about my fonts, please sent an email to ndrienugrie@gmail.com

 

This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 

Paypal account for donation : https://www.paypal.me/ndrienugrie

Link to purchase full version and commercial license: 
https://fontbundles.net/ndrienugrie

Thanks,

Nug's Project